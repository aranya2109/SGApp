import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee.component';
import { DepartmentComponent } from './department.component';

const routes: Routes = [
  { path: '', component: EmployeeComponent, data: { title: 'First Component' } },
  { path: 'first', component: EmployeeComponent, data: { title: 'First Component' } },
  { path: 'second', component: DepartmentComponent, data: { title: 'Second Component' } }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
