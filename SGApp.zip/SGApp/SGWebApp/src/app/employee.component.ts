import { Component } from '@angular/core';
import { AppService } from './app.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { MatTableDataSource } from '@angular/material';

export interface Employee {
    emp_id: string;
    emp_name: string;
    salary: number;
    state: string;
    date_of_joining: string;
    dept_name: string;
}

@Component({
    selector: 'emp',
    templateUrl: './employee.component.html'
})
export class EmployeeComponent {

    ELEMENT_DATA: Employee[];
    employees: Employee[];
    displayedColumns: string[] = ['emp_id', 'emp_name', 'salary', 'state', 'date_of_joining', 'dept_name'];
    dataSource: MatTableDataSource<Employee>;
    options: Employee[];
    srchStr: string;
    filteredOptions: Observable<string[]>;
    empChk: boolean = true;
    deptChk: boolean = false;
    stateChk: boolean = false;

    constructor(public appSer: AppService) {

    }

    ngOnInit() {
        this.dataSource = new MatTableDataSource<Employee>();
        this.loadEmployees();
    }

    filterList(val: any) {
        this.dataSource.data = this.employees.filter(x => x.emp_id == val.option.value.emp_id);
    }

    deptToggle(e: any) {
        this.deptChk = e.checked;
        this.empChk = this.stateChk = !this.deptChk;
        if (this.deptChk) {
            this.srchStr = "";
            this.getByDept();
        }
    }

    stateToggle(e: any) {
        this.stateChk = e.checked;
        this.empChk = this.deptChk = !this.stateChk;
        if (this.stateChk) {
            this.srchStr = "";
            this.getByState();
        }
    }

    empToggle(e: any) {
        this.empChk = e.checked;
        this.deptChk = this.stateChk = !this.empChk;
        if (this.empChk)
            this.dataSource.data = this.ELEMENT_DATA = this.employees;
    }

    loadEmployees() {
        this.appSer.getAllEmployees().subscribe(response => {
            this.ELEMENT_DATA = response;
            this.employees = this.options = this.dataSource.data = this.ELEMENT_DATA;
        });
    }

    getByDept() {
        this.appSer.getByDept().subscribe(res => {
            this.ELEMENT_DATA = res;
            this.dataSource.data = this.ELEMENT_DATA;
        });
    }

    getByState() {
        this.appSer.getByState().subscribe(res => {
            this.ELEMENT_DATA = res;
            this.dataSource.data = this.ELEMENT_DATA;
        });
    }

    displayValue(val: any) {
        if (typeof val == "object" && val !== null && val !== undefined) {
            return val.emp_name;
        }

        return null;
    }

    filterOptions() {
        if (this.srchStr !== undefined && this.srchStr !== null && this.options !== null && this.options !== undefined) {
            this.options = this.employees.filter(x => x.emp_name == this.srchStr);
            if (this.options.length > 0) {
                return;
            }
        }
        this.options = this.employees;
        this.dataSource.data = this.employees;
    }
}
