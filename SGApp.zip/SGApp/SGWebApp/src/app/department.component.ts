import { Component } from '@angular/core';

@Component({
  selector: 'dept',
  templateUrl: './dept.component.html',
})
export class DepartmentComponent {
  title = 'SGWebApp';
}
