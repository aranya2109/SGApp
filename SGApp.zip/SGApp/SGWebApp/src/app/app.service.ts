import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AppService {

    appUrl = "http://localhost:50147/";

  constructor(private http : HttpClient) { }

  getAllEmployees():Observable<any>{
    return this.http.get(this.appUrl+"get_all_employees");
  }

  getEmployee(id:number):Observable<any>{
    return this.http.get(this.appUrl+"get_employee?id="+id);
  }

  getCount():Observable<any>{
      return this.http.get(this.appUrl+"get_count");
  }

  getByDept():Observable<any>{
    return this.http.get(this.appUrl+"get_all_employees_by_dept");
  }
  getByState():Observable<any>{
    return this.http.get(this.appUrl+"get_all_employees_by_state");
  }
}