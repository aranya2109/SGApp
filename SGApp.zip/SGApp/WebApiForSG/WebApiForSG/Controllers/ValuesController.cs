﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApiForSG.Business;
using WebApiForSG.Models;

namespace WebApiForSG.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        [ResponseType(typeof(List<Employee>))]
        [Route("get_all_employees")]
        public IHttpActionResult Get()
        {
            IEmployeeManager employeeManager = EmployeeManager.Initialize();
            return Ok(employeeManager.GetAllEmployees());
        }

        // GET api/values/5
        [ResponseType(typeof(List<Employee>))]
        [Route("get_employee")]
        public IHttpActionResult Get(int id)
        {
            IEmployeeManager employeeManager = EmployeeManager.Initialize();
            return Ok(employeeManager.GetEmployee(id));
        }

        [ResponseType(typeof(Employee))]
        [Route("get_count")]
        public IHttpActionResult GetCount()
        {
            IEmployeeManager employeeManager = EmployeeManager.Initialize();
            return Ok(employeeManager.GetCount());
        }

        [ResponseType(typeof(List<Employee>))]
        [Route("get_all_employees_by_dept")]
        public IHttpActionResult GetEmployeesOfEachDepartment()
        {
            IEmployeeManager employeeManager = EmployeeManager.Initialize();
            return Ok(employeeManager.GetEmployeesOfEachDepartment());
        }

        [ResponseType(typeof(List<Employee>))]
        [Route("get_all_employees_by_state")]
        public IHttpActionResult GetEmployeesOfEachState()
        {
            IEmployeeManager employeeManager = EmployeeManager.Initialize();
            return Ok(employeeManager.GetEmployeesOfEachState());
        }
    }
}
