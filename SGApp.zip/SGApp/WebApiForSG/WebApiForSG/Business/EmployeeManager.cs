﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApiForSG.Models;

namespace WebApiForSG.Business
{
    public class EmployeeManager : IEmployeeManager
    {
        static EmployeeManager employeeManager;

        public static EmployeeManager Initialize()
        {
            if(employeeManager == null)
            {
                employeeManager = new EmployeeManager();
            }

            return employeeManager;
        }

        public List<Employee> GetAllEmployees()
        {
            return FormEmployeeData();
        }

        public Employee GetCount()
        {
            Employee employee = new Employee();
            List<Employee> employees = FormEmployeeData();

            employee.state = employees.GroupBy(x=>x.state).Count().ToString();
            employee.dept_name = employees.GroupBy(x => x.dept_name).Count().ToString();
            employee.emp_name = employees.Count().ToString();

            return employee;
        }

        public Employee GetEmployee(int id)
        {
            return FormEmployeeData().FirstOrDefault(x => x.emp_id == id.ToString());
        }

        public List<Employee> GetEmployeesOfEachDepartment()
        {
            List<Employee> employees = FormEmployeeData();

            var emps = (from e in employees
                        group e by e.dept_name into g
                        select new Employee { emp_name = String.Join(",", g.Select(x => x.emp_name)), state = String.Join(",", g.Select(x => x.state)), emp_id = String.Join(",", g.Select(x => x.emp_id)), salary = g.Sum(x=>Convert.ToDecimal(x.salary)).ToString(), dept_name = g.First().dept_name, date_of_joining = String.Join(",", g.Select(x => x.date_of_joining)) }).ToList();

            return emps;
        }

        public List<Employee> GetEmployeesOfEachState()
        {
            List<Employee> employees = FormEmployeeData();

            var emps = (from e in employees
                        group e by e.state into g
                        select new Employee { emp_name = String.Join(",", g.Select(x => x.emp_name)), dept_name = String.Join(",", g.Select(x => x.dept_name)), emp_id = String.Join(",", g.Select(x => x.emp_id)), salary = g.Sum(x => Convert.ToDecimal(x.salary)).ToString(), state = g.First().state, date_of_joining = String.Join(",", g.Select(x => x.date_of_joining)) }).ToList();

            return emps;
        }

        private List<Employee> FormEmployeeData()
        {
            List<Employee> employees = new List<Employee>();
            int dept_id = 1,state_id=1;

            for (int i=1; i <= 100; i++)
            {
                if(dept_id > 3)
                {
                    dept_id = 1;
                }

                if(state_id > 5)
                {
                    state_id = 1;
                }

                Employee employee = new Employee();
                employee.date_of_joining = DateTime.Now.AddDays(i - 410).ToString("dd-MM-yyyy");
                employee.emp_id = i.ToString();
                employee.salary = ( i == 4 ? (i % 5 ) * 55000 : (i % 4) * 100000).ToString();
                employee.emp_name = "Emp " + i;
                employee.dept_name = "Dept " + dept_id++;
                employee.state = "State " + state_id++;

                employees.Add(employee);
            }

            return employees;
        }
    }
}