﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApiForSG.Models;

namespace WebApiForSG.Business
{
    public interface IEmployeeManager
    {
        Employee GetEmployee(int id);
        List<Employee> GetAllEmployees();
        List<Employee> GetEmployeesOfEachDepartment();
        List<Employee> GetEmployeesOfEachState();
        Employee GetCount();
    }
}